print('KD-tree')

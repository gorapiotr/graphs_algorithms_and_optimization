class Node:

    def __init__(self, left_child, right_child, straight, d):
        self.left_child = left_child
        self.right_child = right_child
        self.straight = straight
        self.d = d

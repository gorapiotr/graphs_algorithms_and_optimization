print('DetectMaxima')
